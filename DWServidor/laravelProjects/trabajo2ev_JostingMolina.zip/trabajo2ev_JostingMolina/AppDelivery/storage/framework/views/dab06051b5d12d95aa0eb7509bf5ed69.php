<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App Delivery</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet"> 
   

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

     <!-- Fonts -->
     <link rel="preconnect" href="https://fonts.bunny.net">
     <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

     <!-- Scripts -->
     <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
     <script src="https://cdn.jsdelivr.net/npm/animejs/lib/anime.min.js"></script>

    <style>

  a:hover{
        text-decoration: underline;
        color: black;
  }
  .navegacion__link--registrar:hover{
    text-decoration: underline;
    color: white;


  }

  .product__cart{
    display: grid;
    grid-template-columns: auto auto;
    align-content: center;
    align-items: center;
    font-size: 0.8em;

  }

  .error{
    background-color: #303f46;;
    padding: 5px;
    color: white;
    font-weight: bold;

}
    </style>
</head>
<body>
    <header class="header ">
        <div class="header__logo">
            <img src="<?php echo e(asset('img/logo.svg')); ?>" alt="logo">
        </div>
        <div>
            <nav class="navegacion">
           
                <a href="<?php echo e(url('/')); ?>" class="navegacion__link">Inicio</a>
                <a href="<?php echo e(url('/products')); ?>" class="navegacion__link">Platos</a>
                <a href="<?php echo e(url('/companyDeliveries')); ?>" class="navegacion__link">Empresas</a>
                <a href="<?php echo e(url('/orders')); ?>" class="navegacion__link">Pedidos</a>
        
                <a class="navegacion__link" href="<?php echo e(url('/cart')); ?>">
                    
                    <span><i class="bi bi-cart-plus-fill"> Carrito</i></span>
                  </a>
            </nav>
        </div>
        <nav class="navegacion">
           
            <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>

                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                            <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4"/>
                            <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z"/>
                          </svg>
                          <?php echo e(Auth::user()->name); ?>

                    </div>
                        <form  method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                           

                        <button class="navegacion__link" type="submit">Cerrar sesion</button>
                        </form>
                   
                           <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="navegacion__link--registrar">Iniciar sesion</a>
                            <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="navegacion__link--registrar">Crear cuenta</a>
                            <?php endif; ?>
                    <?php endif; ?>
            <?php endif; ?>
        </nav>
    </header>

    <div class="container mt-4">
        <h1 class="text-center mb-4">Lista de Productos</h1>
    
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="product" class="col-md-4 mb-4">
                    <div class="card">
                        <img src="<?php echo e($product->image); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                            <p class="fw-bold">Precio: €<?php echo e(number_format($product->price, 2)); ?></p>
                            <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                <input type="hidden" name="image" value="<?php echo e($product->image); ?>">
                                <input type="hidden" name="company" value="<?php echo e($product->company_id); ?>">
                                <button type="submit" class="btn bg-red-600 text-white font-bold">Añadir al Carrito</button>
                            </form>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($products->links('pagination::bootstrap-5')); ?>

        </div>
    </div>

    
</body>
</html><?php /**PATH /home/isard/Escritorio/FP_DAW/DWServidor/laravelProjects/trabajo2ev_JostingMolina/AppDelivery/resources/views/products.blade.php ENDPATH**/ ?>