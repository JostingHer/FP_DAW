<?php

require_once "controllers/App.php";
$app = new App;
$app->run();
