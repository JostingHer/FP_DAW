<?php

define('CONEXION', 'mysql:dbname=bbddExamen;host=localhost');
define('USUARIO', 'root');
define('CLAVE', '');
